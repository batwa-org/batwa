from rest_framework import serializers
from .models import Users,Transaction,Settings,Template
class UsersSerializer(serializers.ModelSerializer):
    class Meta:
        model = Users
        fields = ["idUsers",
        "first_name",
        "last_name",
        "dob",
        "contact",
        "username",
        "userpass",
        "currbalance",
        "avgexpense",
        "totalexpenses",
        "totalincomes",
        "totaldebt"
        ]

class TransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Transaction
        fields = ["idTransaction",
        "Users_idUsers",
        "date",
        "amount",
        "is_debit",
        "categoryname",
        "is_debt",
        "iconlink"
        ]

class SettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Settings
        fields = ["idSettings",
        "Users_idUsers",
        "currency",
        "maxexplimW",
        "notificationOn",
        "altertType",
        "maxexplimM",
        "maxexplimD",
        "maxlimexceededOn",
        "indebtOn",
        "perofmaxlimOn",
        "dailytransremOn"
        ]

class TemplateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Template
        fields = ["idTemplate",
        "Users_idUsers",
        "amount",
        "is_debit",
        "categoryname",
        "iconlink"
        ]




