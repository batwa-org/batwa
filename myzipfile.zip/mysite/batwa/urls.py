from django.urls import path, include
from .views import (
    UsersTable,
    TransactionTable,
    SettingsTable,
    TemplateTable
)


urlpatterns = [
    path('api/users/<str:name>/<str:password>/', UsersTable.as_view()),
    path('api/users', UsersTable.as_view()),
    path('api/transactions/<int:userid>/', TransactionTable.as_view()),
    path('api/transactions/<int:transactionid>/<int:userid>/', TransactionTable.as_view()),
    path('api/settings/<int:userid>/', SettingsTable.as_view()),
    path('api/templates/<int:userid>/', TemplateTable.as_view()),
    path('api/templates/<int:templateid>/<int:userid>/', TemplateTable.as_view()),
]