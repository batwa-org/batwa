from django.shortcuts import render
from django.http import HttpResponse

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Users,Transaction,Settings,Template
from .serializers import UsersSerializer, TransactionSerializer, SettingsSerializer, TemplateSerializer
from rest_framework import permissions
from django.db.models import F
from django.http import JsonResponse


from datetime import date

def hello(request):
    return render(request, "base.html")

"""
def login(request):
    return render(request, "login.html")

def register(request):
    return render(request, "register.html")
"""

class UsersTable(APIView):
    def get_object(self, name, password):
        '''
        Helper method to get the object with given username, and password
        '''
        try:
            return Users.objects.get(username=name, userpass=password)
        # do something with the user object
        except Users.DoesNotExist:
        # handle the case where the user does not exist
            return None

    def get(self, request, name, password, *args, **kwargs):
        '''
        Retrieves the profile with given username and password
        '''
        user = self.get_object(name, password)
        if not user:
            return Response(
                {"res": "Incorrect Username or Password"},
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer = UsersSerializer(user)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, name, password, *args, **kwargs):
        '''
        updates a user record in the users table with given data (can be partial from example only contact can be sent)
        '''
        user = self.get_object(name, password)
        if not user:
            return Response(
                {"res": "User is not registered"},
                status=status.HTTP_400_BAD_REQUEST
            )

        data = {}
        update_fields = ['first_name', 'last_name', 'dob', 'contact', 'username', 'userpass', 'currbalance', 'avgexpense', 'totalexpenses' ,'totalincomes', 'totaldebt']
        for field in update_fields:
            if request.data.get(field) is not None:
                data[field] = request.data.get(field)

        new_username = data.get('username', None)
        if new_username and Users.objects.exclude(idUsers=user.idUsers).filter(username=new_username).exists():
            return Response(
                {"res": "Username already exists"},
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer = UsersSerializer(instance=user, data=data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def delete(self, request, name, password, *args, **kwargs):
        '''
        Deletes the user from the Users table
        '''
        user = self.get_object(name, password)
        if not user:
            return Response(
                {"res": "user deleted!"},
                status=status.HTTP_400_BAD_REQUEST
            )
        user.delete()
        return Response(
            {"res": "Object deleted!"},
            status=status.HTTP_200_OK
        )

    def post(self, request, *args, **kwargs):
        '''
        Create a new user in the Users table
        '''
        data = {}
        update_fields = ['first_name', 'last_name', 'dob', 'contact', 'username', 'userpass', 'currbalance', 'avgexpense', 'totalexpenses' ,'totalincomes', 'totaldebt']
        for field in update_fields:
            if request.data.get(field) is not None:
                data[field] = request.data.get(field)

        if Users.objects.filter(username=data.get('username')).exists():
            return Response({'error': 'Username already exists'}, status=status.HTTP_400_BAD_REQUEST)


        serializer = UsersSerializer(data=data)
        if serializer.is_valid():
            userinstance = serializer.save()
            #create entry in settings table

            #Settings.objects.create(Users_idUsers=userinstance.idUsers)
            Settings.objects.create(Users_idUsers=userinstance)

            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class TransactionTable(APIView):
    def get_object(self, userid,transactionid=-1):
        '''
        Helper method to get the object with given userid
        '''
        if transactionid==-1:
            try:
                return Transaction.objects.filter(Users_idUsers = userid)
            # do something with the user object
            except Transaction.DoesNotExist:
            # handle the case where the user does not exist
                return None

        try:
            return Transaction.objects.get(idTransaction=transactionid,Users_idUsers =userid)
        # do something with the user object
        except Transaction.DoesNotExist:
        # handle the case where the user does not exist
            return None



    def get(self, request, userid, *args, **kwargs):
        '''
        Retrieves the transactions associated with a user
        '''
        transactions = self.get_object(userid)
        if not transactions:
            return Response(
                {"res": "This user does not have any transactions"},
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer = TransactionSerializer(transactions,many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, transactionid, userid, *args, **kwargs):
        '''
        updates a transaction record in the users table with given data
        '''
        transaction = self.get_object(userid, transactionid)
        if not transaction:
            return Response(
                {"res": "No such transaction"},
                status=status.HTTP_400_BAD_REQUEST
            )

        data = {}
        update_fields = ['date', 'amount', 'is_debit', 'categoryname', 'is_debt', 'iconlink']
        for field in update_fields:
            if request.data.get(field) is not None:
                data[field] = request.data.get(field)
            #based on certain field make relevant to other places in the database.

        serializer = TransactionSerializer(instance=transaction, data=data, partial=True)
        if serializer.is_valid():
            transaction = serializer.save()
            """
            if data['is_debt'] exists and data['is_debt] == True then
                update totaldebt(Users table)=totaldebt + amount
                update currbalance(Users table) = currbalance - amount
            if data['is_debit'] exists and data['is_debit'] == True then
                update totalincomes(Users table) = totalincomes + amount
                currbalance(Users table) = currbalance + amount
            if data['is_debit'] exists and data['is_debit'] == False then
                update totalexpenses(Users table) = totalexpenses + amount
                currbalance(Users table) = currbalance - amount
            """

            if data.get('is_debt') and data['is_debt']:
                Users.objects.filter(pk=userid).update(totaldebt=F('totaldebt') + transaction.amount)
                Users.objects.filter(pk=userid).update(currbalance=F('currbalance') - transaction.amount)

            if data.get('is_debit') and data['is_debit']:
                Users.objects.filter(pk=userid).update(totalincomes=F('totalincomes') + transaction.amount)
                Users.objects.filter(pk=userid).update(currbalance=F('currbalance') + transaction.amount)

            if data.get('is_debit') is not None and not data['is_debit']:
                Users.objects.filter(pk=userid).update(totalexpenses=F('totalexpenses') + transaction.amount)
                Users.objects.filter(pk=userid).update(currbalance=F('currbalance') - transaction.amount)

            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, transactionid, userid,*args, **kwargs):
        '''
        Deletes a transaction from the table
        '''
        if transactionid != 0:
            transaction = self.get_object(userid,transactionid)
            if not transaction:
                return Response(
                    {"res": "No such transaction"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            transaction.delete()
            return Response(
                {"res": "Object deleted!"},
                status=status.HTTP_200_OK
            )

        transactions = self.get_object(userid)
        if not transactions:
            return Response(
                {"res": "all transactions not deleted"},
                status=status.HTTP_400_BAD_REQUEST
            )
        transactions.delete()
        return Response(
            {"res": "Objects deleted!"},
            status=status.HTTP_200_OK
        )



    def post(self, request, userid, *args, **kwargs):
        '''
        add a new transaction for a given user
        '''
        data = {}
        data['Users_idUsers'] = userid
        update_fields = ['date', 'amount', 'is_debit', 'categoryname', 'is_debt', 'iconlink']
        for field in update_fields:
            if request.data.get(field) is not None:
                data[field] = request.data.get(field)

        serializer = TransactionSerializer(data=data)
        if serializer.is_valid():
            transaction = serializer.save()

            if data.get('is_debt') and data['is_debt']:
                Users.objects.filter(pk=userid).update(totaldebt=F('totaldebt') + transaction.amount)
                Users.objects.filter(pk=userid).update(currbalance=F('currbalance') - transaction.amount)

            if data.get('is_debit') and data['is_debit']:
                Users.objects.filter(pk=userid).update(totalincomes=F('totalincomes') + transaction.amount)
                Users.objects.filter(pk=userid).update(currbalance=F('currbalance') + transaction.amount)

            if data.get('is_debit') is not None and not data['is_debit']:
                Users.objects.filter(pk=userid).update(totalexpenses=F('totalexpenses') + transaction.amount)
                Users.objects.filter(pk=userid).update(currbalance=F('currbalance') - transaction.amount)


            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class SettingsTable(APIView):
    def get_object(self, userid):
        '''
        Helper method to get the object with given userid
        '''
        try:
            return Settings.objects.get(Users_idUsers= userid)
        # do something with the user object
        except Settings.DoesNotExist:
        # handle the case where the user does not exist
            return None

    def get(self, request, userid, *args, **kwargs):
        '''
        Retrieves the setting for a given user
        '''
        usersettings = self.get_object(userid)
        if not usersettings:
            return Response(
                {"res": "Incorrect Username and Password"},
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer = SettingsSerializer(usersettings)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, userid, *args, **kwargs):
        '''
        updates the settings for a give user
        '''
        usersettings = self.get_object(userid)
        if not usersettings:
            return Response(
                {"res": "This user doesnot have any settings associated with them"},
                status=status.HTTP_400_BAD_REQUEST
            )

        data = {}
        update_fields = ['currency', ' maxexplimW', 'notificationOn', 'altertType', 'maxexplimM', 'maxexplimD', 'maxlimexceededOn', 'indebtOn', 'perofmaxlimOn' ,'dailytransremOn']
        for field in update_fields:
            if request.data.get(field) is not None:
                data[field] = request.data.get(field)

        serializer = SettingsSerializer(instance=usersettings, data=data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    """
    def delete(self, request, userid, *args, **kwargs):
        '''
        Deletes the user from the Users table
        '''
        usersettings = self.get_object(userid)
        if not usersettings:
            return Response(
                {"res": "user settings deleted!"},
                status=status.HTTP_400_BAD_REQUEST
            )
        usersettings.delete()
        return Response(
            {"res": "Object deleted!"},
            status=status.HTTP_200_OK
        )

    def post(self, request, *args, **kwargs):
        '''
        Create a new user in the Users table
        '''
        data = {}
        data['Users_idUsers']=userid
        update_fields = ['currency', ' maxexplimW', 'notificationOn', 'altertType', 'maxexplimM', 'maxexplimD', 'maxlimexceededOn', 'indebtOn', 'perofmaxlimOn' ,'dailytransremOn']
        for field in update_fields:
            if request.data.get(field) is not None:
                data[field] = request.data.get(field)

        serializer = SettingsSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            #create entry in settings table
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    """


class TemplateTable(APIView):
    def get_object(self, userid,templateid=-1):
        '''
        Helper method to get the object with given userid
        '''
        if templateid==-1:
            try:
                return Template.objects.filter(Users_idUsers = userid)
            # do something with the user object
            except Template.DoesNotExist:
            # handle the case where the user does not exist
                return None

        try:
            return Template.objects.get(idTemplate=templateid,Users_idUsers =userid)
        # do something with the user object
        except Template.DoesNotExist:
        # handle the case where the user does not exist
            return None



    def get(self, request, userid, *args, **kwargs):
        '''
        Retrieves the templates associated with a user
        '''
        templates = self.get_object(userid)
        if not templates:
            return Response(
                {"res": "This user does not have any templates"},
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer = TemplateSerializer(templates,many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, templateid, userid, *args, **kwargs):
        '''
        updates a template in the users table with given data
        '''
        template = self.get_object(userid, templateid)
        if not template:
            return Response(
                {"res": "No such template"},
                status=status.HTTP_400_BAD_REQUEST
            )

        data = {}
        update_fields = ['amount', 'is_debit', 'categoryname', 'iconlink']
        for field in update_fields:
            if request.data.get(field) is not None:
                data[field] = request.data.get(field)
                #based on certain field make relevant to other places in the database.

        serializer = TemplateSerializer(instance=template, data=data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, templateid, userid,*args, **kwargs):
        '''
        Deletes a template from the table
        '''
        if templateid != 0:
            template = self.get_object(userid,templateid)
            if not template:
                return Response(
                    {"res": "No such template"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            template.delete()
            return Response(
                {"res": "Object deleted!"},
                status=status.HTTP_200_OK
            )

        templates = self.get_object(userid)
        if not templates:
            return Response(
                {"res": "all transactions not deleted"},
                status=status.HTTP_400_BAD_REQUEST
            )
        templates.delete()
        return Response(
            {"res": "Objects deleted!"},
            status=status.HTTP_200_OK
        )



    def post(self, request, userid, *args, **kwargs):
        '''
        add a new template for a given user
        '''
        data = {}
        data['Users_idUsers'] = userid
        update_fields = ['amount', 'is_debit', 'categoryname', 'iconlink']
        for field in update_fields:
            if request.data.get(field) is not None:
                data[field] = request.data.get(field)

        serializer = TemplateSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)















