from django.contrib import auth
from django.db import models

# Create your models here.
class Users(models.Model):
    idUsers = models.AutoField(primary_key=True)
    first_name = models.TextField()
    last_name = models.TextField()
    dob = models.DateField(null=True, blank=True)
    contact = models.TextField()
    username = models.TextField()
    userpass = models.TextField()
    currbalance = models.FloatField(default=0)
    avgexpense = models.FloatField(default=0)
    totalexpenses = models.FloatField(default=0)
    totalincomes = models.FloatField(default=0)
    totaldebt = models.FloatField(default=0)

class Transaction(models.Model):
    idTransaction = models.AutoField(primary_key=True)
    Users_idUsers = models.ForeignKey(Users, on_delete=models.CASCADE)
    date = models.DateField()
    amount = models.FloatField(default=0)
    is_debit = models.BooleanField(default=False)
    categoryname = models.TextField()
    is_debt = models.BooleanField(default=False)
    iconlink = models.TextField(null=True, blank=True)

class Settings(models.Model):
    idSettings = models.AutoField(primary_key=True)
    Users_idUsers = models.ForeignKey(Users, on_delete=models.CASCADE)
    currency = models.TextField(default='PKR')
    maxexplimW = models.FloatField(null=True, blank=True)
    notificationOn = models.BooleanField(default=True)
    altertType = models.TextField(null=True, blank=True)
    maxexplimM = models.FloatField(null=True, blank=True)
    maxexplimD = models.FloatField(null=True, blank=True)
    maxlimexceededOn = models.BooleanField(default=True)
    indebtOn = models.BooleanField(default=True)
    perofmaxlimOn = models.BooleanField(default=True)
    dailytransremOn = models.BooleanField(default=True)

class Template(models.Model):
    idTemplate = models.AutoField(primary_key=True)
    Users_idUsers = models.ForeignKey(Users, on_delete=models.CASCADE)
    amount = models.FloatField(default=0)
    is_debit = models.BooleanField(default=False)
    categoryname = models.TextField()
    iconlink = models.TextField(null=True, blank=True)